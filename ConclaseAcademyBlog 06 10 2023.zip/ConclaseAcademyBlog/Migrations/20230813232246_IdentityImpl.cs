﻿namespace ConclaseAcademyBlog.Migrations
{
    public class _20230813232246IdentityImpl
    {
    }
}
