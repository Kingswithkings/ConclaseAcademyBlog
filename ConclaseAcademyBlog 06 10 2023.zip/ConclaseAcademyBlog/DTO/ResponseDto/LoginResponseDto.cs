﻿namespace ConclaseAcademyBlog.DTO.ResponseDto
{
    public class LoginResponseDto
    {
        public string Token { get; set; }
    }
}
