﻿namespace ConclaseAcademyBlog.DTO.Generic
{
    public class ResponseError
    {
        public int Code { get; set; }
        public string Type { get; set; }
    }
}
