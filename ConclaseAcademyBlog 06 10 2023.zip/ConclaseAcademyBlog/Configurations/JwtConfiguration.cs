﻿using System;

namespace ConclaseAcademyBlog.Configurations
{
    public class JwtConfiguration
    {
        public string Secret { get; set; }
        public double JwtExpiryTime { get; set; }
    }
}
